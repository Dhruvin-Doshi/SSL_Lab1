mkdir outputs/
cp $(find inputs/ -type f -name "*.txt") ./outputs
find ./outputs -type f -name "*.txt" | sort | xargs cat -n >cat.txt
grep -v "^$" $(find ./outputs -type f -name "*.txt") | wc -l > lines.txt
